function veranderKleur() {
    document.getElementById("tekst").style.backgroundColor = ;
}
